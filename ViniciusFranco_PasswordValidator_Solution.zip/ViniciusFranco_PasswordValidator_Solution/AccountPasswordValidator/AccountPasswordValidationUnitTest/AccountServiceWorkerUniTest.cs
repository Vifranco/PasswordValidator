using AccountPasswordValidation;
using AccountPasswordValidation.Contracts;
using NUnit.Framework;
using Moq;
using Microsoft.Extensions.Logging;

namespace AccountPasswordValidationUnitTest
{
    public class Tests
    {
        Mock<ILogger<AccountServiceWorker>> mockLogger;
        PasswordValidatorSettings passwordValidatorSettings;
        AccountServiceWorker accountServiceWorker;

        [SetUp]
        public void Setup()
        {
            mockLogger = new Mock<ILogger<AccountServiceWorker>>();
            passwordValidatorSettings = new PasswordValidatorSettings()
            {
                AcceptanceCriteria = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{9,}$",
                UseAccountValidatorMock = false
            };
            accountServiceWorker = new AccountServiceWorker(mockLogger.Object, passwordValidatorSettings);
        }

        [Test]
        public void Test1_NullPassword()
        {           
            SignInAuthRequest request = new SignInAuthRequest()
            {
                userPassword = null
            };

            var result = accountServiceWorker.AuthenticatePassword(request).Result;

            Assert.IsFalse(result.IsValid, "Password should not be valid");
        }

        [Test]
        public void Test2_EmptyPassword()
        {
            SignInAuthRequest request = new SignInAuthRequest()
            {
                userPassword = ""
            };

            var result = accountServiceWorker.AuthenticatePassword(request).Result;

            Assert.IsFalse(result.IsValid, "Password should not be valid");
        }

        [Test]
        public void Test3_OnlyLowerCase_1()
        {
            SignInAuthRequest request = new SignInAuthRequest()
            {
                userPassword = "aa"
            };

            var result = accountServiceWorker.AuthenticatePassword(request).Result;

            Assert.IsFalse(result.IsValid, "Password should not be valid");
        }

        [Test]
        public void Test4_OnlyLowerCase_2()
        {
            SignInAuthRequest request = new SignInAuthRequest()
            {
                userPassword = "ab"
            };

            var result = accountServiceWorker.AuthenticatePassword(request).Result;

            Assert.IsFalse(result.IsValid, "Password should not be valid");
        }

        [Test]
        public void Test5_OnlyLetters()
        {
            SignInAuthRequest request = new SignInAuthRequest()
            {
                userPassword = "AAAbbbCc"
            };

            var result = accountServiceWorker.AuthenticatePassword(request).Result;

            Assert.IsFalse(result.IsValid, "Password should not be valid");
        }

        [Test]
        public void Test6_ValidPassword()
        {  
            SignInAuthRequest request = new SignInAuthRequest()
            {
                userPassword = "AbTp9!foo"
            };

            var result = accountServiceWorker.AuthenticatePassword(request).Result;

            Assert.IsTrue(result.IsValid, "Password should be valid");
        }


        [Test]
        public void Test7_OnlyNumber()
        {
            SignInAuthRequest request = new SignInAuthRequest()
            {
                userPassword = "123"
            };

            var result = accountServiceWorker.AuthenticatePassword(request).Result;

            Assert.IsFalse(result.IsValid, "Password should not be valid");
        }
    }
}
using AccountPasswordValidation;
using AccountPasswordValidation.Contracts;
using NUnit.Framework;
using Moq;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace AccountPasswordValidationUnitTest
{
    public class Tests
    {
        Mock<ILogger<UserRegisterServiceWorker>> mockLogger;
        PasswordValidatorSettings passwordValidatorSettings;
        UserRegisterServiceWorker accountServiceWorker;

        [SetUp]
        public void Setup()
        {
            mockLogger = new Mock<ILogger<UserRegisterServiceWorker>>();
            passwordValidatorSettings = new PasswordValidatorSettings()
            {
                AcceptanceCriteria = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{9,}$",
                UseAccountValidatorMock = false
            };
            accountServiceWorker = new UserRegisterServiceWorker(mockLogger.Object, passwordValidatorSettings);
        }

        [TestCase("AbTp9!foo", true, TestName = "ValidPassword")]
        [TestCase(null, false, TestName = "NullPassword")]
        [TestCase("", false, TestName = "EmptyPassword")]
        [TestCase("aa", false, TestName = "OnlyLowerCase_1")]
        [TestCase("ab", false, TestName = "OnlyLowerCase_2")]
        [TestCase("AAAbbbCc", false, TestName = "OnlyLetters")]
        [TestCase("123", false, TestName = "OnlyNumber")]
        public async Task Test(string userPassword, bool expectedValue)
        {
            PasswordValidatorRequest request = new PasswordValidatorRequest()
            {
                userPassword = userPassword
            };

            var result = await accountServiceWorker.ValidatePassword(request);

            Assert.AreEqual(result.IsValid, expectedValue, $"Password should {(expectedValue ? "" : "not")} be valid");
        }
    }
}
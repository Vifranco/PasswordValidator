using System;

namespace AccountPasswordValidation
{
    public class PasswordValidatorResponse<T>
    {
        public T IsValid { get; set; }
        public string Message { get; set; }
    }
}

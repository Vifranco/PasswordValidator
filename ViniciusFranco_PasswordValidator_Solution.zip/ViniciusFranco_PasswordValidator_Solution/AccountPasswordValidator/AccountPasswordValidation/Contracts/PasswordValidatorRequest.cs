using System;

namespace AccountPasswordValidation
{
    public class PasswordValidatorRequest
    {
        public string userPassword { get; set; }

        public string userName { get; set; }
    }
}

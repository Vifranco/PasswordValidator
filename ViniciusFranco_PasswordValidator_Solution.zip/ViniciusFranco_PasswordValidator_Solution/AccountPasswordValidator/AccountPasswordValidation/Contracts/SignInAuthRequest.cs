using System;

namespace AccountPasswordValidation
{
    public class SignInAuthRequest
    {
        public string userPassword { get; set; }

        public string userName { get; set; }
    }
}

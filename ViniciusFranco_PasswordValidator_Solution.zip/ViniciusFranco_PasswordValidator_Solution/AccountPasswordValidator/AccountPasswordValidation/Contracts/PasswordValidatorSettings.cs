﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AccountPasswordValidation.Contracts
{
    public class PasswordValidatorSettings
    {
        public string AcceptanceCriteria { get; set; }

        public bool UseAccountValidatorMock { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AccountPasswordValidation
{
    public class AccountServiceMock : IAccountService
    {
        Task<SignInAuthResponse<bool>> IAccountService.AuthenticatePassword(SignInAuthRequest request)
        {
            throw new NotImplementedException();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AccountPasswordValidation
{
    public interface IAccountService
    {
        Task<SignInAuthResponse<bool>> AuthenticatePassword(SignInAuthRequest request);      
    }
}

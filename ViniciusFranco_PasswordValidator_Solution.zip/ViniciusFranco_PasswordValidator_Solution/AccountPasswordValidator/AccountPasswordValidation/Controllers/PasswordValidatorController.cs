﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace AccountPasswordValidation.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PasswordValidatorController : ControllerBase
    {

        private readonly ILogger<PasswordValidatorController> _logger;
        private readonly IUserRegisterService _accountService;

        public PasswordValidatorController(ILogger<PasswordValidatorController> logger, IUserRegisterService accountService)
        {
            _logger = logger;
            _accountService = accountService;
        }

        [HttpPost]
        public async Task<PasswordValidatorResponse<bool>> PasswordValidator([FromBody] PasswordValidatorRequest requestBody)
        {
            var response = await _accountService.ValidatePassword(requestBody);            
            return response;
        }

    }
}

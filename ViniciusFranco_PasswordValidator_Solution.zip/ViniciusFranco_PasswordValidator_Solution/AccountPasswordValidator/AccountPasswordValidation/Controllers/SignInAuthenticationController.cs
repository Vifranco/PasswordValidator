﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace AccountPasswordValidation.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SignInAuthenticationController : ControllerBase
    {

        private readonly ILogger<SignInAuthenticationController> _logger;
        private readonly IAccountService _accountService;

        public SignInAuthenticationController(ILogger<SignInAuthenticationController> logger, IAccountService accountService)
        {
            _logger = logger;
            _accountService = accountService;
        }

        [HttpPost]
        public async Task<SignInAuthResponse<bool>> SignInAuthentication([FromBody] SignInAuthRequest requestBody)
        {
            SignInAuthResponse<bool> response =  await _accountService.AuthenticatePassword(requestBody);                      
            return response;
        }

    }
}

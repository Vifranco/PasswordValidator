﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using AccountPasswordValidation.Contracts;

namespace AccountPasswordValidation
{
    public class UserRegisterServiceWorker : IUserRegisterService
    {
        private readonly ILogger<UserRegisterServiceWorker> _logger;

        private readonly PasswordValidatorSettings _appsettings;
        public UserRegisterServiceWorker(ILogger<UserRegisterServiceWorker> logger, PasswordValidatorSettings appsettings)
        {
            _logger = logger;
            _appsettings = appsettings;
        }
        public async Task<PasswordValidatorResponse<bool>> ValidatePassword(PasswordValidatorRequest request)
        {
            bool isValid;
            var password = request?.userPassword;
            var response = new PasswordValidatorResponse<bool>();

            try {
                if (!string.IsNullOrEmpty(password))
                {
                    isValid = await PasswordValidator(password);

                    if (isValid)
                    {
                        response.Message = "Authorized";

                        _logger.LogDebug("Password is Valid");
                    }
                    else
                    {
                        response.Message = "Password does not match the acceptance criteria";

                        _logger.LogDebug("Password does not match the acceptance criteria");

                    }
                }
                else
                {
                    isValid = false;
                    response.Message = "Enter a Password";

                    _logger.LogError("Password is empty");
                }
            }
            catch(Exception ex)
            {
                isValid = false;
                response.Message = "Empty Password";

                _logger.LogError(ex, "Error during user password validation");
            }

            response.IsValid = isValid;

            return response;
        }

        private Task<bool> PasswordValidator(string password)
        {
            var pattern = @_appsettings.AcceptanceCriteria;

            return Task.Run(() => Regex.IsMatch(password, pattern));
       
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using AccountPasswordValidation.Contracts;

namespace AccountPasswordValidation
{
    public class AccountServiceWorker : IAccountService
    {
        private readonly ILogger<AccountServiceWorker> _logger;

        private readonly PasswordValidatorSettings _appsettings;
        public AccountServiceWorker(ILogger<AccountServiceWorker> logger, PasswordValidatorSettings appsettings)
        {
            _logger = logger;
            _appsettings = appsettings;
        }
        public async Task<SignInAuthResponse<bool>> AuthenticatePassword(SignInAuthRequest request)
        {
            bool isValid;
            var password = request?.userPassword;
            var response = new SignInAuthResponse<bool>();

            try {
                if (!string.IsNullOrEmpty(password))
                {
                    isValid = PasswordValidator(password);

                    if (isValid)
                    {
                        response.Message = "Authorized";

                        _logger.LogDebug("Password is Valid");
                    }
                    else
                    {
                        response.Message = "Unauthorized";

                        _logger.LogDebug("Password does not match the acceptance criteria");

                    }
                }
                else
                {
                    isValid = false;
                    response.Message = "Unknown Password";

                    _logger.LogError("Password is empty");
                }
            }
            catch(Exception ex)
            {
                isValid = false;
                response.Message = "Unknown Password";

                _logger.LogError(ex, "Error during user password validation");
            }

            response.IsValid = isValid;

            return response;
        }

        private bool PasswordValidator(string password)
        {
            var pattern = @_appsettings.AcceptanceCriteria;

            var isMatch = Regex.IsMatch(password, pattern);

            return isMatch;
       
        }
    }
}

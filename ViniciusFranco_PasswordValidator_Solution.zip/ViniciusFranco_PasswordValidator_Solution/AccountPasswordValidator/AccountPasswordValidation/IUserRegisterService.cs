﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AccountPasswordValidation
{
    public interface IUserRegisterService
    {
       Task<PasswordValidatorResponse<bool>> ValidatePassword(PasswordValidatorRequest request);      
    }
}
